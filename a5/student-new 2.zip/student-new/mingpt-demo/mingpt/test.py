a = [i for i in range(10) ]

print(a[1:2])