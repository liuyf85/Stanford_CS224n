import torch
import torch.nn as nn
import torch.nn as nn

class model(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.linear = nn.Linear(self.input_size, self.hidden_size)

        self.relu = nn.ReLU()
        self.linear2 = nn.Linear(self.hidden_size, self.input_size) 
        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        linear = self.linear(x)
        relu = self.relu(linear) 
        linear2 = self.linear2(relu) 
        output = self.sigmoid(linear2) 
        return output
    def fuck(self, x, y, z) : 
        print("fuck you")
# Make a sample input
input = torch.randn(2, 5) # Create our model
model = model(5, 3)
print(model(1, 2, 3))
# Pass our input through our model